import { useState } from "react";
import Header from "./components/Header";
import ProductList from "./components/ProductList";
import ProductDetail from "./components/ProductDetail";
import ShoppingCart from "./components/ShoppingCart";
import Search from "./components/Search";
import UserAccount from "./components/UserAccount";
import "./styles.css";

export default function App() {
  // Dummy data for products and cart items
  const [cartItems, setCartItems] = useState([
    // Add initial cart items here
    { id: 1, name: "Mast & Harbour", price: 598, quantity: 2 },
    { id: 2, name: "Roadster", price: 619, quantity: 1 },
    { id: 3, name: "Roadster", price: 639, quantity: 3 },
  ]);
  const [products, setProducts] = useState([
    // Add initial products here
    {
      id: 1,
      name: "Mast & Harbour",
      description: "Men Slim Fit Casual Sustainable Shirt",
      price: 598,
      image:
        "https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/8717979/2019/3/20/585db9fe-1df0-458d-b218-6f514eabb9601553068826233-Mast--Harbour-Men-Shirts-4141553068825026-1.jpg",
    },
    {
      id: 2,
      name: "Roadster",
      description: "Men Cotton Casual Shirt",
      price: 619,
      image:
        "https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/2127876/2017/11/23/11511431472633-Roadster-Men-Black-Regular-Fit-Solid-Casual-Shirt-8801511431472500-1.jpg",
    },
    {
      id: 3,
      name: "Roadster",
      description: "Men Cotton Casual Shirt",
      price: 639,
      image:
        "https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/9951411/2019/8/5/fe1322b7-9e53-4b6e-8423-0a4f5a9e8b4b1565006161882-Roadster-Men-Shirts-8701565006159466-1.jpg",
    },
    {
      id: 4,
      name: "HERE&NOW",
      description: "Slim Fit Casual Shirt",
      price: 645,
      image:
        "https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/19818628/2022/9/6/ec27eee6-d613-4423-8e0f-007aea1603c31662468109188Shirts1.jpg",
    },
    {
      id: 5,
      name: "Powerlook",
      description: "Opaque casual shirt",
      price: 1187,
      image:
        "https://assets.myntassets.com/f_webp,dpr_1.5,q_60,w_210,c_limit,fl_progressive/assets/images/24681706/2023/8/27/5e9ad3d5-951b-4b00-8a13-e1dcea0878cd1693134857976PowerlookMenMulticolouredTartanChecksOpaqueCheckedCasualShir1.jpg",
    },
  ]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const handleProductClick = (product) => {
    setSelectedProduct(product);
  };

  const handleAddToCart = (product) => {
    const existingItemIndex = cartItems.findIndex(
      (item) => item.id === product.id
    );
    if (existingItemIndex !== -1) {
      const updatedCartItems = [...cartItems];
      updatedCartItems[existingItemIndex].quantity++;
      setCartItems(updatedCartItems);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  };

  return (
    <div className="App">
      <Header />
      <main>
        {/* Render different components based on route or state */}
        {/* For simplicity, you can replace this logic with React Router */}
        {selectedProduct ? (
          <ProductDetail
            product={selectedProduct}
            addToCart={handleAddToCart}
          />
        ) : (
          <>
            <Search />
            <ProductList products={products} addToCart={handleAddToCart} />
          </>
        )}
        <ShoppingCart cartItems={cartItems} />
        {cartItems.length === 0 && <p>Your cart is empty.</p>}
        <UserAccount />
      </main>
      <footer>
        {/* Add footer content */}
        <p>© 2024 Your Ecommerce Website</p>
      </footer>
    </div>
  );
}
