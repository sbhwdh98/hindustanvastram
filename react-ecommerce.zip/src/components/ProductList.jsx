import React, { useState } from "react";
import ProductDetail from "./ProductDetail";

const ProductList = ({ products, addToCart }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const handleProductClick = (product) => {
    setSelectedProduct(product);
  };

  return (
    <div className="product-list">
      {products.map((product) => (
        <div
          key={product.id}
          className="product"
          onClick={() => handleProductClick(product)}
        >
          {/* Display product details */}
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <p>Price: ₹{product.price}</p>
          <button onClick={() => addToCart(product)}>Add To Cart</button>
        </div>
      ))}
      {selectedProduct && (
        <ProductDetail product={selectedProduct} addToCart={addToCart} />
      )}
    </div>
  );
};

export default ProductList;
