import React from "react";

const Header = () => {
  return (
    <header>
      {/* Add your header content here */}
      {/* <h1>Vastram</h1> */}
      <nav>
        <ul>
          {/* Add navigation links here */}
          <h1>Vastram</h1>

          <li>
            <a href="/">Home</a>
          </li>
          <li>
            <a href="/products">Products</a>
          </li>
          <li>
            <a href="/cart">Cart</a>
          </li>
          <li>
            <a href="/account">Account</a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
