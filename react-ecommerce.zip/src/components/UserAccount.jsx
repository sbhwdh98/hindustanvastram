import React from "react";

const UserAccount = () => {
  return (
    <div className="user-account">
      <h2>User account</h2>
      {/* Add user account details and options */}
      <p>Welcome, User!</p>
      <button>Logout</button>
    </div>
  );
};

export default UserAccount;
